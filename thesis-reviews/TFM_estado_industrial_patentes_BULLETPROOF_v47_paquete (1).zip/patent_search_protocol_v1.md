# Protocolo reproducible v1 - corpus patentario multi-AMR

**Fecha de corte:** 2026-09-11  
**Unidad de análisis principal:** publicación patentaria.  
**Objetivo:** caracterizar descriptivamente la cobertura temática, geográfica y sectorial del corpus relacionado con coordinación multi-vehículo, carga compartida y transporte cooperativo. No se interpreta el conteo de publicaciones como número de invenciones.

## Fuentes y recuperación
- Google Patents como enlace operativo a cada publicación del dataset.
- Búsqueda textual por combinaciones de: `cooperative transport`, `collaborative transport`, `shared load`, `same cargo`, `multi-AGV`, `multi-AMR`, `synchronized transport`, `cooperative carrying`, `robot recruitment`, `task allocation`, `fleet scheduling`, `coupling`, `docking`, `force distribution`, `wrench`, `physical feasibility`.
- CPC de soporte para regeneración/ampliación: G05D 1/69 (control coordinado multi-vehículo), 1/692 (vehículos dispares), 1/695 (posición relativa/formación), 1/696 (vehículos acoplados), 1/698 (asignación de autoridad), 1/6983 (control distribuido/secuencial), 1/6985 (líder/seguidor) y 1/6987 (control centralizado externo).
- Expansión por solicitante y *snowballing* de documentos/familias relacionadas.

## Inclusión
1. Publicación 2012-2025 relacionada explícitamente con al menos una categoría del codebook.
2. Título/abstract o metadatos suficientes para justificar la codificación temática.
3. URL trazable a la publicación.

## Exclusión
1. Duplicado confirmado de una misma familia ya representada por otra publicación cuando la duplicación fue auditada.
2. Documento fuera de alcance temático tras verificación.
3. Registro sin identificador de publicación trazable.

## Codificación
- Una etiqueta temática principal (`theme_label`) por publicación para evitar doble conteo en el panel temático.
- Una macrocapa (`Mission decision`, `Coordination`, `Physical interaction`).
- La clasificación es analítica, no una clasificación jurídica a nivel de *claims*.

## Temporalidad
- El eje temporal usa **año de publicación**. `priority_year` solo está disponible en 6/167 registros analíticos de la versión v3; por ello los gráficos no se interpretan como ritmo de invención.
- Para el cambio temático se usan ventanas simétricas 2020-2022 y 2023-2025.

## Geografía
- Solo se usa `applicant_country` cuando `country_basis = identified/curated assignee entity`.
- La ampliación dirigida por solicitante se marca separadamente y no se interpreta como cuota mundial.

## Familias y sensibilidad
- La versión v3 sigue siendo **publication-level**. La auditoría familiar completa se mantiene como artefacto separado (`family_audit_queue.csv`).
- Como prueba de sensibilidad, se colapsan de forma conservadora cuatro grupos de títulos altamente similares. Este colapso **no** determina pertenencia a una familia. La cuota de decisión de misión pasa de 39.1% a 59.1% (+20.0 p.p.), por lo que la conclusión cualitativa persiste.

## Artefactos
- `patent_dataset_2012_2025_AUDITADO_v3.csv`
- `patent_coding_codebook_v1.csv`
- `family_similarity_sensitivity_clusters.csv`
- `family_audit_queue.csv`

## Fuentes metodológicas de apoyo
- CPC G05D, definiciones oficiales USPTO: https://www.uspto.gov/web/patents/classification/cpc/html/defG05D.html
- CPC G05D, esquema oficial: https://www.uspto.gov/web/patents/classification/cpc/html/cpc-G05D.html
- Familias patentarias EPO: https://www.epo.org/en/searching-for-patents/helpful-resources/first-time-here/patent-families
- WIPO Guidelines for Preparing Patent Landscape Reports: https://www.wipo.int/edocs/pubdocs/en/patents/946/wipo_pub_946.pdf
- OECD Patent Statistics Manual: https://www.oecd.org/content/dam/oecd/en/publications/reports/2009/02/oecd-patent-statistics-manual_g1gh9fa4/9789264056442-en.pdf
