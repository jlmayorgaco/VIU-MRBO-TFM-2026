# Informe de auditoría metodológica del corpus - v1

- Filas totales: 169
- Publicaciones analíticas: 167
- Excluidas por duplicidad familiar confirmada: 2
- Registros con `priority_year`: 6
- Registros con familia `not_audited`: 161
- Grupos de sensibilidad por similitud de título/solicitante: 4 (9 publicaciones)

## Resultado de sensibilidad
Ventana 2020-2022: decisión de misión 37.9% en el corpus principal y 39.1% tras colapso conservador de grupos candidatos.  
Ventana 2023-2025: 58.8% y 59.1%, respectivamente.  
Cambio: +20.9 p.p. principal; +20.0 p.p. sensibilidad.

## Interpretación
El resultado temático es estable ante esta perturbación conservadora, pero el colapso no sustituye una auditoría jurídica de familias. La tesis debe describir la figura como análisis descriptivo a nivel de publicación.
