# Estado del bloque industrial/patentario v46

Esta versión queda cerrada metodológicamente **a nivel de publicación patentaria**. No debe describirse como análisis exhaustivo de familias o invenciones mientras exista una cola de auditoría familiar pendiente.

## Claims permitidos
- Distribución temática y temporal del corpus de publicaciones curado.
- Diagnóstico de cobertura geográfica de solicitantes identificados.
- Comparación descriptiva de dominios de aplicación.
- Ausencia de integración pública de todas las capacidades del TFM **dentro de los precedentes revisados**.

## Claims que deben evitarse
- 'Número de invenciones' o 'número de familias' para los 167 registros.
- Cuotas mundiales por país.
- Fecha de invención a partir del año de publicación.
- Inexistencia absoluta de una solución comercial equivalente.

## Antes del depósito VIU
- Refluir el contenido dentro de la plantilla oficial VIU.
- Sustituir numeración interna de citas por APA 7 en la memoria final.
- Usar entornos figure/table y labels de la plantilla para índices automáticos.
